
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import sqlite3
import threading
import time
from collections import defaultdict
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent
HTML_PATH = ROOT / "public" / "index.html"
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "kore_rp.sqlite3"

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))
ADMIN_USER = os.getenv("KORE_ADMIN_USER", "admin")
SESSION_TTL_DAYS = int(os.getenv("KORE_SESSION_DAYS", "7"))

# ── Admin password (required — no default) ───────────────────────────────────
_ADMIN_PASS_RAW = os.getenv("KORE_ADMIN_PASSWORD", "")
if not _ADMIN_PASS_RAW:
    raise SystemExit(
        "FATAL: KORE_ADMIN_PASSWORD environment variable is not set.\n"
        "Set it before starting the server: export KORE_ADMIN_PASSWORD=<strong-password>"
    )

# Hash once at startup with PBKDF2-SHA256 + random salt (never store plaintext)
_ADMIN_SALT: bytes = secrets.token_bytes(32)
_ADMIN_HASH: bytes = hashlib.pbkdf2_hmac(
    "sha256", _ADMIN_PASS_RAW.encode(), _ADMIN_SALT, 260_000
)
del _ADMIN_PASS_RAW  # remove raw password from memory

def _check_admin_password(password: str) -> bool:
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), _ADMIN_SALT, 260_000)
    return secrets.compare_digest(h, _ADMIN_HASH)

# ── Rate limiting ─────────────────────────────────────────────────────────────
_LOGIN_WINDOW = 300   # 5 minutes
_LOGIN_MAX    = 10    # max attempts per IP per window
_login_attempts: Dict[str, List[float]] = defaultdict(list)
_login_lock = threading.Lock()

def _check_rate_limit(ip: str) -> bool:
    now = time.time()
    with _login_lock:
        valid = [t for t in _login_attempts[ip] if now - t < _LOGIN_WINDOW]
        _login_attempts[ip] = valid
        if len(valid) >= _LOGIN_MAX:
            return False
        _login_attempts[ip].append(now)
        return True

# ── Secure cookies (auto-detect HTTPS proxy) ─────────────────────────────────
_COOKIE_SECURE = os.getenv("COOKIE_SECURE", "1" if os.getenv("REPL_ID") else "0") == "1"

# ── Email OTP ─────────────────────────────────────────────────────────────────
ADMIN_EMAIL  = os.getenv("KORE_ADMIN_EMAIL", "").strip().lower()
GAME_PACKAGE = os.getenv("KORE_GAME_PACKAGE", "com.MA.LAC").strip()
_OTP_TTL     = 600  # 10 minutes
_OTP_MAXFAIL = 5
_otp_store: Dict[str, Dict[str, Any]] = {}
_otp_lock = threading.Lock()

def _generate_otp() -> str:
    return str(100000 + secrets.randbelow(900000))

def _send_otp_email(to_email: str, otp: str) -> None:
    import smtplib
    from email.mime.text import MIMEText

    # Fallbacks for the mailbox you provided so OTP delivery works out of the box.
    host = os.getenv("SMTP_HOST", "smtp.gmail.com").strip()
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER", "rxn707233@gmail.com").strip()
    pwd  = os.getenv("SMTP_PASS", "xbac ypxd bdcu hegl").replace(" ", "").strip()
    from_ = os.getenv("SMTP_FROM", user).strip() or user

    if not user or not pwd:
        raise RuntimeError("SMTP_USER / SMTP_PASS غير مهيأة")

    body  = (
        f"مرحباً,\n\nكود تسجيل الدخول لبوابة KØRE RP:\n\n"
        f"    {otp}\n\n"
        f"الكود صالح لمدة 10 دقائق. لا تشاركه مع أحد.\n\n— فريق KØRE RP"
    )
    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = f"كود دخول KØRE RP: {otp}"
    msg["From"]    = from_
    msg["To"]      = to_email
    with smtplib.SMTP(host, port) as smtp:
        smtp.starttls()
        smtp.login(user, pwd)
        smtp.sendmail(from_, to_email, msg.as_string())

DEFAULT_PRODUCTS = [
    {"id":"house-studio", "cat":"property", "name":"شقة استوديو", "desc":"وحدة صغيرة مناسبة للبداية داخل المدينة", "price":3},
    {"id":"house-apartment", "cat":"property", "name":"شقة عائلية", "desc":"شقتين غرف داخل مجمع سكني مزدحم", "price":6},
    {"id":"house-villa", "cat":"property", "name":"فيلا خاصة", "desc":"فيلا واسعة مع كراج خاص وحديقة", "price":12},
    {"id":"house-mansion", "cat":"property", "name":"قصر فاخر", "desc":"أكبر عقار متاح بموقع مميز داخل اللعبة", "price":20},
    {"id":"coins-small", "cat":"coins", "name":"200 KØRE Coins", "desc":"دفعة صغيرة من عملة السيرفر الداخلية", "price":2},
    {"id":"coins-medium", "cat":"coins", "name":"600 KØRE Coins", "desc":"دفعة متوسطة، أوفر للمشتريات الأكبر", "price":5},
    {"id":"coins-large", "cat":"coins", "name":"1500 KØRE Coins", "desc":"دفعة كبيرة بأفضل سعر للوحدة", "price":10},
    {"id":"weapon-pistol", "cat":"weapon", "name":"مسدس خدمة", "desc":"سلاح دفاعي أساسي لشخصيتك داخل اللعبة", "price":2},
    {"id":"weapon-rifle", "cat":"weapon", "name":"بندقية متوسطة", "desc":"سلاح أقوى لسيناريوهات RP الجادة", "price":7},
    {"id":"weapon-special", "cat":"weapon", "name":"عتاد خاص", "desc":"تجهيزات إضافية حسب نوع السيناريو", "price":12},
    {"id":"mod-paint", "cat":"mod", "name":"طلاء مخصص", "desc":"لون وتشطيب مخصص لسيارتك", "price":1},
    {"id":"mod-rims", "cat":"mod", "name":"جنوط رياضية", "desc":"طقم جنوط بتصميم مميز", "price":2},
    {"id":"mod-performance", "cat":"mod", "name":"ترقية أداء", "desc":"تحسين سرعة واستجابة السيارة", "price":5},
    {"id":"mod-bodykit", "cat":"mod", "name":"باكيج هيكل كامل", "desc":"تعديل شامل لمظهر السيارة", "price":8},
]

DEFAULT_CONFIG = {
    "brandTitle": "KØRE RP",
    "brandSubtitle": "Portal",
    "infoPageTitle": "المعلومات",
    "infoPageSubtitle": "معلومات مرتبة بشكل نظيف وواضح.",
    "infoHeroTitle": "KØRE<br>Roleplay Portal",
    "infoHeroDesc": "الوصول إلى المعلومات الأساسية، القوانين، والتقديم.",
    "storePageTitle": "المتجر",
    "storePageSubtitle": "كل الأسعار بعملة KØRE Coins داخل اللعبة، معروضة بالدينار الليبي كرمز فقط. ما فيه فلوس حقيقية تتحرك هنا.",
    "storeHeroTitle": "عقارات، عتاد،<br>وتعديلات",
    "storeHeroDesc": "اشترِ ببساطة، خذ كود طلبك، وخلّص داخل اللعبة مع الإدارة.",
    "gamePackage": GAME_PACKAGE,
}

def now_ts() -> int:
    return int(time.time())

def json_dumps(obj: Any) -> str:
    # Escape < to avoid ending the script tag early.
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")

def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    conn = connect()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            sid TEXT PRIMARY KEY,
            role TEXT NOT NULL,
            username TEXT NOT NULL DEFAULT '',
            dark INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            expires_at INTEGER NOT NULL,
            csrf_token TEXT NOT NULL DEFAULT ''
        )
    """)
    # Migration: add csrf_token to existing DBs
    try:
        cur.execute("ALTER TABLE sessions ADD COLUMN csrf_token TEXT NOT NULL DEFAULT ''")
    except Exception:
        pass
    cur.execute("""
        CREATE TABLE IF NOT EXISTS config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            data TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id TEXT PRIMARY KEY,
            cat TEXT NOT NULL,
            name TEXT NOT NULL,
            "desc" TEXT NOT NULL,
            price INTEGER NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS applications (
            id TEXT PRIMARY KEY,
            code TEXT NOT NULL,
            approvalCode TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL,
            createdAt INTEGER NOT NULL,
            name TEXT NOT NULL,
            age TEXT NOT NULL,
            discord TEXT NOT NULL DEFAULT '',
            reason TEXT NOT NULL,
            experience TEXT NOT NULL DEFAULT '',
            level TEXT NOT NULL,
            levelLabel TEXT NOT NULL
        )
    """)

    if cur.execute("SELECT COUNT(*) FROM config").fetchone()[0] == 0:
        cur.execute("INSERT INTO config (id, data) VALUES (1, ?)", (json.dumps(DEFAULT_CONFIG, ensure_ascii=False),))

    if cur.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
        for p in DEFAULT_PRODUCTS:
            cur.execute(
                "INSERT INTO products (id, cat, name, \"desc\", price) VALUES (?, ?, ?, ?, ?)",
                (p["id"], p["cat"], p["name"], p["desc"], int(p["price"]))
            )

    conn.commit()
    conn.close()

def load_config(conn: sqlite3.Connection) -> Dict[str, Any]:
    row = conn.execute("SELECT data FROM config WHERE id = 1").fetchone()
    if not row:
        return dict(DEFAULT_CONFIG)
    try:
        data = json.loads(row["data"])
        if not isinstance(data, dict):
            raise ValueError
        merged = dict(DEFAULT_CONFIG)
        merged.update(data)
        return merged
    except Exception:
        return dict(DEFAULT_CONFIG)

def save_config(conn: sqlite3.Connection, cfg: Dict[str, Any]) -> None:
    conn.execute(
        "INSERT INTO config (id, data) VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET data = excluded.data",
        (json.dumps(cfg, ensure_ascii=False),),
    )

def load_products(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    rows = conn.execute('SELECT id, cat, name, "desc", price FROM products ORDER BY rowid ASC').fetchall()
    return [dict(r) for r in rows]

def save_products(conn: sqlite3.Connection, products: List[Dict[str, Any]]) -> None:
    conn.execute("DELETE FROM products")
    for p in products:
        conn.execute(
            'INSERT INTO products (id, cat, name, "desc", price) VALUES (?, ?, ?, ?, ?)',
            (
                str(p.get("id", "")),
                str(p.get("cat", "")),
                str(p.get("name", "")),
                str(p.get("desc", "")),
                int(p.get("price", 0)),
            )
        )

def load_applications(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    rows = conn.execute("""
        SELECT id, code, approvalCode, status, createdAt, name, age, discord, reason, experience, level, levelLabel
        FROM applications
        ORDER BY createdAt ASC
    """).fetchall()
    return [dict(r) for r in rows]

def replace_applications(conn: sqlite3.Connection, apps: List[Dict[str, Any]]) -> None:
    conn.execute("DELETE FROM applications")
    for app in apps:
        conn.execute("""
            INSERT INTO applications
            (id, code, approvalCode, status, createdAt, name, age, discord, reason, experience, level, levelLabel)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            str(app.get("id", "")),
            str(app.get("code", "")),
            str(app.get("approvalCode", "")),
            str(app.get("status", "pending")),
            int(app.get("createdAt", now_ts() * 1000)),
            str(app.get("name", "")),
            str(app.get("age", "")),
            str(app.get("discord", "")),
            str(app.get("reason", "")),
            str(app.get("experience", "")),
            str(app.get("level", "")),
            str(app.get("levelLabel", "")),
        ))

def session_row(conn: sqlite3.Connection, sid: str) -> Optional[sqlite3.Row]:
    row = conn.execute("SELECT * FROM sessions WHERE sid = ?", (sid,)).fetchone()
    if not row:
        return None
    if int(row["expires_at"]) <= now_ts():
        conn.execute("DELETE FROM sessions WHERE sid = ?", (sid,))
        conn.commit()
        return None
    return row

def get_cookie_sid(handler: BaseHTTPRequestHandler) -> Optional[str]:
    raw = handler.headers.get("Cookie")
    if not raw:
        return None
    jar = cookies.SimpleCookie()
    try:
        jar.load(raw)
    except Exception:
        return None
    morsel = jar.get("kore_session")
    return morsel.value if morsel else None

def current_session(conn: sqlite3.Connection, handler: BaseHTTPRequestHandler) -> Optional[sqlite3.Row]:
    sid = get_cookie_sid(handler)
    if not sid:
        return None
    return session_row(conn, sid)

def set_session_cookie(handler: BaseHTTPRequestHandler, sid: str) -> None:
    max_age = SESSION_TTL_DAYS * 24 * 60 * 60
    cookie = cookies.SimpleCookie()
    cookie["kore_session"] = sid
    cookie["kore_session"]["path"] = "/"
    cookie["kore_session"]["httponly"] = True
    cookie["kore_session"]["samesite"] = "Lax"
    cookie["kore_session"]["max-age"] = str(max_age)
    if _COOKIE_SECURE:
        cookie["kore_session"]["secure"] = True
    handler.send_header("Set-Cookie", cookie.output(header="").strip())

def clear_session_cookie(handler: BaseHTTPRequestHandler) -> None:
    cookie = cookies.SimpleCookie()
    cookie["kore_session"] = ""
    cookie["kore_session"]["path"] = "/"
    cookie["kore_session"]["httponly"] = True
    cookie["kore_session"]["samesite"] = "Lax"
    cookie["kore_session"]["max-age"] = "0"
    if _COOKIE_SECURE:
        cookie["kore_session"]["secure"] = True
    handler.send_header("Set-Cookie", cookie.output(header="").strip())

def bootstrap_payload(conn: sqlite3.Connection, handler: BaseHTTPRequestHandler) -> Dict[str, Any]:
    sess = current_session(conn, handler)
    return {
        "session": None if not sess else {
            "role": sess["role"],
            "username": sess["username"],
            "dark": bool(sess["dark"]),
            "csrfToken": sess["csrf_token"] if sess["csrf_token"] else "",
        },
        "config": load_config(conn),
        "products": load_products(conn),
        "applications": load_applications(conn),
    }

def _check_csrf(handler: BaseHTTPRequestHandler, sess: Optional[sqlite3.Row]) -> bool:
    """Validate CSRF token sent in X-CSRF-Token header against the session."""
    if not sess:
        return False
    token_hdr = handler.headers.get("X-CSRF-Token", "")
    stored = sess["csrf_token"] if sess["csrf_token"] else ""
    return bool(token_hdr and stored and secrets.compare_digest(token_hdr, stored))

class Handler(BaseHTTPRequestHandler):
    server_version = "KoreRP/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        # Quieter logs.
        print("[%s] %s - %s" % (self.log_date_time_string(), self.address_string(), fmt % args))

    def _send_json(self, code: int, payload: Any, extra_headers: Optional[Dict[str, str]] = None) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, code: int, html: str, extra_headers: Optional[Dict[str, str]] = None) -> None:
        body = html.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0") or "0")
        raw = self.rfile.read(length) if length > 0 else b"{}"
        try:
            data = json.loads(raw.decode("utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def do_GET(self) -> None:
        if self.path == "/kore/download-files":
            import zipfile, io
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.write(ROOT / "server.py", "server.py")
                zf.write(ROOT / "public" / "index.html", "public/index.html")
                zf.write(ROOT / "public" / "manifest.json", "public/manifest.json")
                zf.write(ROOT / "public" / "sw.js", "public/sw.js")
            data = buf.getvalue()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", 'attachment; filename="kore-rp-files.zip"')
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)
            return
        if self.path in ("/", "/index.html"):
            self.handle_index()
            return
        if self.path == "/.well-known/assetlinks.json":
            fpath = ROOT / "public" / "assetlinks.json"
            if fpath.exists():
                data = fpath.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(data)
            else:
                self._send_json(404, {"error": "not found"})
            return
        if self.path.startswith("/kore/bootstrap"):
            with connect() as conn:
                payload = bootstrap_payload(conn, self)
            self._send_json(200, payload)
            return
        # Static files
        static_map = {
            "/kore-logo.jpg": ("image/jpeg", ROOT / "public" / "kore-logo.jpg"),
            "/manifest.json": ("application/manifest+json", ROOT / "public" / "manifest.json"),
            "/kore-icon-192.png": ("image/png", ROOT / "public" / "kore-icon-192.png"),
            "/kore-icon-512.png": ("image/png", ROOT / "public" / "kore-icon-512.png"),
            "/kore-icon-192-maskable.png": ("image/png", ROOT / "public" / "kore-icon-192-maskable.png"),
            "/kore-icon-512-maskable.png": ("image/png", ROOT / "public" / "kore-icon-512-maskable.png"),
            "/sw.js": ("application/javascript", ROOT / "public" / "sw.js"),
        }
        # sw.js must never be cached so the browser always picks up updates immediately
        NO_CACHE_FILES = {"/sw.js", "/manifest.json"}
        if self.path in static_map:
            mime, fpath = static_map[self.path]
            if fpath.exists():
                data = fpath.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(len(data)))
                if self.path in NO_CACHE_FILES:
                    self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
                else:
                    self.send_header("Cache-Control", "public, max-age=86400")
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_error(404, "Not found")
            return

        self.send_error(404, "Not found")

    def do_POST(self) -> None:
        if self.path == "/kore/send-otp":
            self.handle_send_otp()
            return
        if self.path == "/kore/session":
            self.handle_login()
            return
        if self.path == "/kore/logout":
            self.handle_logout()
            return
        m = re.match(r"^/kore/applications/([A-Za-z0-9_-]+)/approve$", self.path)
        if m:
            self.handle_approve_application(m.group(1))
            return
        m = re.match(r"^/kore/applications/([A-Za-z0-9_-]+)/reject$", self.path)
        if m:
            self.handle_reject_application(m.group(1))
            return
        self.send_error(404, "Not found")

    def do_PUT(self) -> None:
        if self.path == "/kore/state":
            self.handle_save_state()
            return
        self.send_error(404, "Not found")

    def handle_index(self) -> None:
        if not HTML_PATH.exists():
            self.send_error(500, "index.html missing")
            return
        with connect() as conn:
            boot = json_dumps(bootstrap_payload(conn, self))
        html = HTML_PATH.read_text(encoding="utf-8")
        html = html.replace("window.__BOOTSTRAP__ = {};", f"window.__BOOTSTRAP__ = {boot};")
        self._send_html(200, html)

    def handle_send_otp(self) -> None:
        ip = self.client_address[0]
        if not _check_rate_limit(ip):
            self._send_json(429, {"ok": False, "error": "محاولات كثيرة، انتظر 5 دقائق"})
            return
        data  = self._read_json()
        email = str(data.get("email", "")).strip().lower()
        if not email or "@" not in email or "." not in email.split("@")[-1]:
            self._send_json(400, {"ok": False, "error": "البريد الإلكتروني غير صالح"})
            return
        otp = _generate_otp()
        with _otp_lock:
            _otp_store[email] = {"otp": otp, "expires": time.time() + _OTP_TTL, "attempts": 0}
        try:
            _send_otp_email(email, otp)
            self._send_json(200, {"ok": True})
        except Exception as exc:
            print(f"[OTP] send error: {exc}")
            with _otp_lock:
                _otp_store.pop(email, None)
            self._send_json(500, {"ok": False, "error": "فشل إرسال البريد، حاول لاحقاً"})

    def handle_login(self) -> None:
        ip = self.client_address[0]
        if not _check_rate_limit(ip):
            self._send_json(429, {"ok": False, "error": "محاولات كثيرة، انتظر 5 دقائق"})
            return

        data     = self._read_json()
        email    = str(data.get("email", "")).strip().lower()
        password = str(data.get("password", "")).strip()
        otp      = str(data.get("otp", "")).strip()

        if not email:
            self._send_json(400, {"ok": False, "error": "أدخل البريد الإلكتروني"})
            return

        # ── Path A: password login (everyone) ─────────────────────────────
        if password:
            role = "admin" if (ADMIN_EMAIL and email == ADMIN_EMAIL and _check_admin_password(password)) else "user"

        # ── Path B: OTP login ─────────────────────────────────────────────
        elif otp:
            now = time.time()
            with _otp_lock:
                entry = _otp_store.get(email)
                if not entry:
                    self._send_json(400, {"ok": False, "error": "لا يوجد كود مرسل، اطلب كوداً أولاً"})
                    return
                if now > entry["expires"]:
                    del _otp_store[email]
                    self._send_json(400, {"ok": False, "error": "انتهت صلاحية الكود، أعد الطلب"})
                    return
                entry["attempts"] += 1
                if entry["attempts"] > _OTP_MAXFAIL:
                    del _otp_store[email]
                    self._send_json(429, {"ok": False, "error": "تجاوزت عدد المحاولات، أعد طلب الكود"})
                    return
                if not secrets.compare_digest(entry["otp"], otp):
                    self._send_json(400, {"ok": False, "error": "الكود غير صحيح"})
                    return
                del _otp_store[email]
            role = "admin" if (ADMIN_EMAIL and email == ADMIN_EMAIL) else "user"

        else:
            self._send_json(400, {"ok": False, "error": "أدخل كلمة السر أو كود التحقق"})
            return

        role     = role  # already set above
        sid      = secrets.token_urlsafe(32)
        csrf_tok = secrets.token_urlsafe(32)
        now_i    = now_ts()
        expires  = now_i + SESSION_TTL_DAYS * 24 * 60 * 60
        username = str(data.get("username", "")).strip() or email.split("@")[0]

        with connect() as conn:
            conn.execute("""
                INSERT INTO sessions (sid, role, username, dark, created_at, updated_at, expires_at, csrf_token)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (sid, role, username, 0, now_i, now_i, expires, csrf_tok))
            conn.commit()

        self.send_response(200)
        set_session_cookie(self, sid)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(json.dumps(
            {"ok": True, "role": role, "username": username, "dark": False, "csrfToken": csrf_tok},
            ensure_ascii=False
        ).encode("utf-8"))

    def handle_logout(self) -> None:
        sid = get_cookie_sid(self)
        if sid:
            with connect() as conn:
                sess = session_row(conn, sid)
                if sess and not _check_csrf(self, sess):
                    self._send_json(403, {"ok": False, "error": "طلب غير مصرح"})
                    return
                conn.execute("DELETE FROM sessions WHERE sid = ?", (sid,))
                conn.commit()

        self.send_response(200)
        clear_session_cookie(self)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(json.dumps({"ok": True}, ensure_ascii=False).encode("utf-8"))

    def handle_approve_application(self, app_id: str) -> None:
        with connect() as conn:
            sess = current_session(conn, self)
            if not sess or sess["role"] != "admin":
                self._send_json(403, {"ok": False, "error": "غير مصرح"})
                return
            if not _check_csrf(self, sess):
                self._send_json(403, {"ok": False, "error": "طلب غير مصرح"})
                return
            row = conn.execute("SELECT id FROM applications WHERE id = ?", (app_id,)).fetchone()
            if not row:
                self._send_json(404, {"ok": False, "error": "الطلب غير موجود"})
                return
            code = f"OK-{secrets.token_hex(2).upper()}-{100 + secrets.randbelow(9900)}"
            conn.execute(
                "UPDATE applications SET status='approved', approvalCode=? WHERE id=?",
                (code, app_id)
            )
            conn.commit()
            payload = bootstrap_payload(conn, self)
        self._send_json(200, {"ok": True, "approvalCode": code, "state": payload})

    def handle_reject_application(self, app_id: str) -> None:
        with connect() as conn:
            sess = current_session(conn, self)
            if not sess or sess["role"] != "admin":
                self._send_json(403, {"ok": False, "error": "غير مصرح"})
                return
            if not _check_csrf(self, sess):
                self._send_json(403, {"ok": False, "error": "طلب غير مصرح"})
                return
            row = conn.execute("SELECT id FROM applications WHERE id = ?", (app_id,)).fetchone()
            if not row:
                self._send_json(404, {"ok": False, "error": "الطلب غير موجود"})
                return
            conn.execute(
                "UPDATE applications SET status='rejected', approvalCode='' WHERE id=?",
                (app_id,)
            )
            conn.commit()
            payload = bootstrap_payload(conn, self)
        self._send_json(200, {"ok": True, "state": payload})

    def handle_save_state(self) -> None:
        data = self._read_json()
        with connect() as conn:
            sess = current_session(conn, self)
            if not sess:
                self._send_json(401, {"ok": False, "error": "غير مسجل دخول"})
                return
            if not _check_csrf(self, sess):
                self._send_json(403, {"ok": False, "error": "طلب غير مصرح"})
                return

            dark = 1 if bool(data.get("dark")) else 0
            visitor_name = str(data.get("visitorName", "")).strip()
            now = now_ts()
            conn.execute(
                "UPDATE sessions SET dark = ?, username = COALESCE(NULLIF(?, ''), username), updated_at = ? WHERE sid = ?",
                (dark, visitor_name, now, sess["sid"]),
            )

            if sess["role"] == "admin":
                config = data.get("config")
                if isinstance(config, dict):
                    merged = dict(DEFAULT_CONFIG)
                    merged.update({k: str(v) for k, v in config.items()})
                    save_config(conn, merged)

                products = data.get("products")
                if isinstance(products, list):
                    cleaned = []
                    for p in products:
                        if not isinstance(p, dict):
                            continue
                        pid  = str(p.get("id", "")).strip()[:100]
                        name = str(p.get("name", "")).strip()[:100]
                        desc = str(p.get("desc", "")).strip()[:500]
                        cat  = str(p.get("cat", "")).strip()[:30]
                        try:
                            price = int(p.get("price", 0))
                        except Exception:
                            price = 0
                        if not pid or not name or not desc or not cat:
                            continue
                        cleaned.append({"id": pid, "cat": cat, "name": name, "desc": desc, "price": max(price, 0)})
                    save_products(conn, cleaned)
                # Applications are managed exclusively via /approve and /reject endpoints.
            else:
                # Non-admin: only allow submitting new applications.
                applications = data.get("applications")
                if isinstance(applications, list):
                    existing = {row["id"] for row in conn.execute("SELECT id FROM applications").fetchall()}
                    for a in applications:
                        if not isinstance(a, dict):
                            continue
                        aid = str(a.get("id", "")).strip()
                        if not aid or aid in existing:
                            continue
                        # Validate & enforce max lengths
                        name       = str(a.get("name", "")).strip()[:100]
                        age        = str(a.get("age", "")).strip()[:10]
                        discord    = str(a.get("discord", "")).strip()[:50]
                        reason     = str(a.get("reason", "")).strip()[:2000]
                        experience = str(a.get("experience", "")).strip()[:2000]
                        level      = str(a.get("level", "")).strip()[:20]
                        level_lbl  = str(a.get("levelLabel", "")).strip()[:20]
                        if not name or not age or not reason:
                            continue
                        # Server generates the application code — never trust the client
                        server_code = f"APP-{secrets.token_hex(3).upper()}-{100 + secrets.randbelow(900)}"
                        conn.execute("""
                            INSERT INTO applications
                            (id, code, approvalCode, status, createdAt, name, age, discord, reason, experience, level, levelLabel)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """, (
                            aid, server_code, "",
                            "pending",
                            int(a.get("createdAt", now_ts() * 1000)),
                            name, age, discord, reason, experience, level, level_lbl,
                        ))

            conn.commit()
            payload = bootstrap_payload(conn, self)
        self._send_json(200, {"ok": True, "state": payload})

def _session_cleanup_worker() -> None:
    """Background thread: delete expired sessions every hour."""
    while True:
        time.sleep(3600)
        try:
            with connect() as conn:
                conn.execute("DELETE FROM sessions WHERE expires_at <= ?", (now_ts(),))
                conn.commit()
        except Exception:
            pass

def main() -> None:
    init_db()
    threading.Thread(
        target=_session_cleanup_worker, daemon=True, name="session-cleanup"
    ).start()
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"Kore RP portal running on http://{HOST}:{PORT}")
    print(f"Admin user: {ADMIN_USER} | Secure cookies: {_COOKIE_SECURE}")
    httpd.serve_forever()

if __name__ == "__main__":
    main()
