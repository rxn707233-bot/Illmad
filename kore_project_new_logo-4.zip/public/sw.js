const CACHE = 'kore-rp-v5';
// Only truly static, rarely-changing assets are cached. Logo/icons are excluded
// on purpose (see fetch handler below) so branding updates show up immediately.
const STATIC = ['/manifest.json'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(STATIC)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);

  // Never cache the HTML page — always fetch fresh from server
  if (url.pathname === '/' || url.pathname === '/index.html') {
    e.respondWith(fetch(e.request).catch(() => caches.match('/')));
    return;
  }

  // Network-first for the logo/icons — always try to get the latest branding
  // from the server first, only falling back to a cached copy if offline.
  const BRANDING = ['/kore-logo.jpg', '/kore-icon-192.png', '/kore-icon-512.png',
                     '/kore-icon-192-maskable.png', '/kore-icon-512-maskable.png'];
  if (BRANDING.includes(url.pathname)) {
    e.respondWith(
      fetch(e.request).then(res => {
        if (res && res.status === 200) {
          caches.open(CACHE).then(c => c.put(e.request, res.clone()));
        }
        return res;
      }).catch(() => caches.match(e.request))
    );
    return;
  }

  // Cache-first for everything else (static assets that rarely change)
  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(res => {
        if (!res || res.status !== 200 || res.type === 'opaque') return res;
        caches.open(CACHE).then(c => c.put(e.request, res.clone()));
        return res;
      }).catch(() => caches.match('/'));
    })
  );
});
